import UIKit

class ListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var userLoginName : String = ""
    
    var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var selectedRow : Int = 0
    
    @IBOutlet weak var lblLoggedUserName : UILabel!

    @IBOutlet weak var tableView : UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblLoggedUserName.text = userLoginName

        // Do any additional setup after loading the view.
        tableView.dataSource = self
        tableView.delegate = self
    }

//    override func viewWillAppear(_ animated: Bool) {
//        tableView.reloadData()
//    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return Employee.all(context: self.context).count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let Employee = Employee.all(context: self.context)[indexPath.row]
        
        cell.textLabel!.text = Employee.name
        
        return cell

    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        self.selectedRow = indexPath.row
        
        performSegue(withIdentifier: Segue.toInfoViewEditing, sender: nil)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        /*
         Here you have to send the selected object to InfoViewController.
         
         You can get this object by using the self.selectedRow assigned by tabeView didSelectRowAt function.
         
         Remember to prepare the InfoViewController to receive this object.
         */
        
        if segue.identifier == Segue.toInfoViewEditing {
            
            let employeeSelection = Employee.all(context: context)[self.selectedRow]
            
            (segue.destination as! InfoViewController).employeeSelection = employeeSelection
            
        }
        
    }

    
    @IBAction func btnRefreshTouchUp(_ sender : Any?) {
        
        tableView.reloadData()
        
    }
    
    
}
