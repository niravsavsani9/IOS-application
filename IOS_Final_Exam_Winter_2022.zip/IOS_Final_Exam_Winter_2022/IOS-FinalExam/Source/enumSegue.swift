import Foundation

enum Segue {
    
    static let toListView : String = "toListView"

    static let toInfoViewAdding : String = "toInfoViewAdding"

    static let toInfoViewEditing : String = "toInfoViewEditing"

}
