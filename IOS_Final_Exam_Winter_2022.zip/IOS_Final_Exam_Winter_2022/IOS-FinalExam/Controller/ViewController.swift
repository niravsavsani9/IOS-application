import UIKit

class ViewController: UIViewController {
    
   
    @IBOutlet weak var textBoxLogin: UITextField!
    
    @IBOutlet weak var textBoxPassword: UITextField!
    
    @IBOutlet weak var buttonLogin: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        
        if identifier == Segue.toListView {
            
        guard let loginName : String = textBoxLogin.text else {
                
                Toast.ok(view: self, title: "Error!!! Invalid!!!", message: "Please, enter your login / username!!!\n To use this application", handler: nil)
                
                return false
                
            }
                if(loginName.count < 2) {
                    
                    Toast.ok(view: self, title: "Error!!! Invalid!!!", message: "Sorry, You can't enter login / username less than 2 characters", handler: nil)
                    textBoxLogin.text = ""
                    return false
                    
                }
            
            if (textBoxPassword.text != "2110222") {
                
                Toast.ok(view: self, title: "Error!!! Invalid!!!", message: "Sorry, your password is incorrect!!!\n Please enter valid password", handler: nil)
                textBoxPassword.text = ""
                return false
                
            }
            
            return true
            
        }
        
        return false
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        /*
         Implement the code to send the user name to ListViewController.
         */
        (segue.destination as! ListViewController).userLoginName = textBoxLogin.text!
    }
}

