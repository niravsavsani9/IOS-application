import UIKit

class InfoViewController: UIViewController {
    
    var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var employeeSelection : Employee?
    
    @IBOutlet weak var textBoxName: UITextField!
    
    @IBOutlet weak var textBoxEmail: UITextField!
    
    @IBOutlet weak var btnDelete: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        if employeeSelection == nil
        {
            title = "Adding new employee"
            btnDelete.isHidden = true
        }else{
            textBoxName.text = self.employeeSelection!.name
            textBoxEmail.text = self.employeeSelection!.email
            btnDelete.isHidden = false
            title = "Showing/Updating new employee"
        }
        
    }
    
    @IBAction func btnSave(_ sender: Any) {
        
        if self.employeeSelection == nil {

            let newEmployee = Employee(context: context)
            newEmployee.name = textBoxName.text
            newEmployee.email = textBoxEmail.text
            
            if newEmployee.save(context: context) != nil {
                navigationController?.popViewController(animated: true)
            } else {
                Toast.ok(view: self, title: "Error!!!! Invalid!!!!", message: "Ops! Something went wrong with the data.\n Please check it once.")
            }
        } else {
            
            self.employeeSelection!.name = textBoxName.text
            self.employeeSelection!.email = textBoxEmail.text
            
            if self.employeeSelection!.save(context: context) != nil {
                navigationController?.popViewController(animated: true)
            } else {
                Toast.ok(view: self, title: "Error!!!! Invalid!!!!", message: "Ops! Something went wrong with the data.\n Please check it once.")
            }
            
        }
    }
    
    
    @IBAction func btnDeleteTouchUpInside(_ sender: Any) {
        
        if self.employeeSelection!.delete(context: context){
            navigationController?.popViewController(animated: true)
        }
    }
    
}
